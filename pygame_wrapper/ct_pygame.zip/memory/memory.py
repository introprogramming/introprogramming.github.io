
import time
import random
from ct_pygame import *

MY_SCORE = 0

CARDS = [ "abc.png", "apa.png", "bepa.png", "boat.png", "coal.png", "qwerty.png", "red.png" ]

PRESSED_TAGS = []

def addPoints( pts ):
	global MY_SCORE
	MY_SCORE += pts
	updateScore()

def getScoreString():
	global MY_SCORE
	return "Score: " + str( MY_SCORE )

def updateScore():
	ctSetObjectText( "score", getScoreString(), color = ( 0, 0, 0, 255 ) )

def isCard( tag ):
	return "card" in tag

def update():
	global PRESSED_TAGS
	#Make all turned cards rotate.
	for tag in PRESSED_TAGS:
		ctRotateObject( tag, 10.0 )

def start():
	global CARDS
	#Create score label.
	ctCreateText( "score", getScoreString(), color = ( 0, 0, 0, 255 ) )
	ctCreateText( "instructions", "Press on a card to turn it, find all pairs.", position = ( 120, 0 ), color = ( 0, 0, 0, 255 ) )
	#Duplicate each card image path to make a pair.
	image_paths = CARDS + CARDS
	#Now shuffle all cards.
	random.shuffle( image_paths )
	i = 0
	#Create 7 pairs and put them in a grid on the window.
	for y in xrange( 0, 2 ):
		for x in xrange( 0, 7 ):
			tag = "card(" + str( x ) + ":" + str( y ) + ")"
			path = image_paths[ i ]
			i = i + 1
			#Give each card a random rotation for fun!
			ctCreateObject( tag, "hidden.png",
				position = ( ( x + 1 ) * 10 + x * 64, 20 + ( y + 1 ) * 10 + y * 64 ),
				size = ( 64, 64 ), name = path, rotation = random.random() * 360.0 )

def pressed( name, tag, abs_pos, rel_pos ):
	global PRESSED_TAGS, MY_SCORE
	if isCard( tag ) and tag not in PRESSED_TAGS:
		ctSetObjectImage( tag, ctGetObjectName( tag ), size = ( 64, 64 ) )
		PRESSED_TAGS.append( tag )
		#If we have selected two images we will check if they are a pair or not.
		if len( PRESSED_TAGS ) == 2:
			#Force a window update and then pause for a bit.
			ctDrawScene()
			time.sleep( 1.0 )
			#Fetch the two cards' tags.
			tag0 = PRESSED_TAGS[ 0 ]
			tag1 = PRESSED_TAGS[ 1 ]
			if ctGetObjectName( tag0 ) == ctGetObjectName( tag1 ):
				#They are a pair, remove cards and add point.
				ctDestroyObject( tag0 )
				ctDestroyObject( tag1 )
				addPoints( 1 )
			else:
				#They are not a pair, hide cards.
				#Since the card needs a different image if it is hovered
				#we also check that property before deciding what image path to use.
				if ctGetObjectHovered( tag0 ):
					ctSetObjectImage( tag0, "hidden_hovered.png", size = ( 64, 64 ) )
				else:
					ctSetObjectImage( tag0, "hidden.png", size = ( 64, 64 ) )
				if ctGetObjectHovered( tag1 ):
					ctSetObjectImage( tag1, "hidden_hovered.png", size = ( 64, 64 ) )
				else:
					ctSetObjectImage( tag1, "hidden.png", size = ( 64, 64 ) )
			PRESSED_TAGS = []
			#If all cards are gone we draw a message on the screen.
			if MY_SCORE is 7:
				ctCreateText( "winner_message", "YOU WIN", position = ( 200, 100 ), color = ( 0, 0, 0, 255 ) )

def entered( name, tag, abs_pos, rel_pos ):
	global PRESSED_TAGS
	#Highlight the image when moused over, if not yet selected.
	if isCard( tag ) and not ( tag in PRESSED_TAGS ):
		ctSetObjectImage( tag, "hidden_hovered.png", size = ( 64, 64 ) )

def exited( name, tag, abs_pos, rel_pos ):
	global PRESSED_TAGS
	#Remove the highlight from the image when the mouse cursor leaves, and not yet selected.
	if isCard( tag ) and not ( tag in PRESSED_TAGS ):
		ctSetObjectImage( tag, "hidden.png", size = ( 64, 64 ) )

#Attach functions and start game.
ctSetup( 528, 178, "Memory", ( 255, 255, 255, 255 ), 30 )
ctBindFunctions( start = start, update = update, ray_cast = pressed, ray_cast_entered = entered, ray_cast_exited = exited )
ctBegin()
