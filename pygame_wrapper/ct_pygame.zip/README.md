# CT_Pygame

**CT_Pygame** är ett tillägg till Pygame som ni kan använda för att inte behöva strula runt med saker som objekt hantering, bildinladdning, tangent- och musklickningar, kollision och diverse andra saker.

Tillägget bygger på att alla objekt som skapas ges en **tag**, som är en unik textsträng. Sedan används taggen till att på olika sätt ändra just det objektet, som att flytta, snurra eller t.ex. för identifiera när musmarkören flyttas ovanpå objektet.

För att använda tillägget är det bra om ni har lite bekantskap med Python som språk och programmering över lag. Har du det så borde du kunna använda CT\_Pygame utan större problem.

Det finns några exempel som ni kan kolla på som använder CT\_Pygame, ett är memory och det andra är ett enkelt bil spel. Även finns det en mall som ni kan använda när ni börjar, se "mall.py".

Notera att du behöver ha Pygame installerat innan du använder CT\_Pygame!

# Tillgängliga funktioner.

Notera att argument innom parantes är frivilliga och måste inte anges.
Ett exempel är om det står "**minFunktion**( namn, (längd) )" så måste **namn** anges men inte **längd**.

**ctSetup**( wid, hei, title, color )
 * Låter dig sätta vilken storlek, titel och bakgrundsfärg som skall användas på det skapta fönstret.
 - **wid** - Ett positivt heltal för fönstrets bredd.
 - **hei** - Ett positivt heltal för fönstrets höjd.
 - **title** - En textsträng för fönstrets titel.
 - **color** - En tuple med fyra positiva heltal mellan 0 och 255 för en RGBA komponentsfärg.

**ctBindFunctions**( (start), (update), (key\_pressed), (key\_released), (key\_held), (mouse\_moved), (mouse\_pressed), (mouse\_released), (ray\_cast), (ray\_cast\_entered), (ray\_cast\_exited), (collision) )
 * Anger vilka funktioner som skall tillkallas när olika saker inträffar i programmet, som när två objekt krockar eller en tangent blir nedtryckt. Notera att om en funktion inte binds till en vis typ av handling så kommer handlingen inte att inträffa, vilket kan snabba upp programmet om det tidigare gick långsamt!
 - **start**() - Tillkallas när programmet startar.
 - **update**() - Tillkallas en gång innan varje ny uppdatering av vad som visas i fönstret.
 - **key_pressed**(key) - Tillkallas när en tangent trycks ned. **key** är en konstant som kan nås via Pygame, t.ex. "pygame.K_UP" för upp på piltangenterna.
 - **key_released**(key) - Tillkallas när en tangent släpps. **key** är en konstant som kan nås via Pygame, t.ex. "pygame.K_UP" för upp på piltangenterna.
 - **key_held**(key) - Tillkallas en gång innan varje uppdatering av vad som visas i fönstret för varje ned tryckt tangent. **key** är en konstant som kan nås via Pygame, t.ex. "pygame.K_UP" för upp på piltangenterna.
 - **mouse_moved**(buttons) - Tillkallas när musmarkören flyttas runt på fönstret. **buttons** anger vilka musknappar som är nedtryckta.
 - **mouse_pressed**(button) - Tillkallas när en musknapp trycks ned i fönstret. **button** anger vilka musknapp som trycktes.
 - **mouse_released**(button) - Tillkallas när en musknapp trycks ned i fönstret. **button** anger vilka musknapp som trycktes.
 - **ray_cast**(name, tag, abs\_pos, rel\_pos) - Tillkallas när ett objekt blir klickat på med musmarkören, eller när funktionen **ctRayCast** används.
   **name** anger ett namn som identifierar vilken "raycast" som funktionsanroppet kommer från.
   **tag** är taggen för det objekt som blev clickat.
   **abs_pos** anger den position som en tuple (x, y)på fönstret som "raycasten" befinner sig på.
   **rel_pos** anger den position som en tuple (x, y) på objektets yta (med rotationen borträknad) som klickades på.
 - **ray_cast_entered**(name, tag, abs\_pos, rel\_pos) - Tillkallas när ett objekt först blir träffat av musmarkören.
   **name** anger ett namn som identifierar vilken "raycast" som funktionsanroppet kommer från.
   **tag** är taggen för det objekt som blev träffat.
   **abs_pos** anger den position som en tuple (x, y)på fönstret som "raycasten" befinner sig på.
   **rel_pos** anger den position som en tuple (x, y) på objektets yta (med rotationen borträknad) som träffades på.
 - **ray_cast_exited**(name, tag, abs\_pos, rel\_pos) - Tillkallas när ett objekt först blir lämnas av musmarkören.
   **name** anger ett namn som identifierar vilken "raycast" som funktionsanroppet kommer från.
   **tag** är taggen för det objekt som blev lämnat.
   **abs_pos** anger den position som en tuple (x, y)på fönstret som "raycasten" befinner sig på.
   **rel_pos** anger den position som en tuple (x, y) på objektets yta (med rotationen borträknad) som lämnades från.
 - **collision**(name, tag0, tag1, corr) - Tillkallas när två "hårda" objekt krockar.
   **name** anger ett namn som identifierar vilken "raycast" som funktionsanroppet kommer från.
   **tag0** är taggen för ett av de två objekten som krockade.
   **tag1** är taggen för det andra av de två objekten som krockade.
   **corr** är en tuple (dx, dy) som anger hur objektet med **tag0** skall flyttas för att motverka kollisionen.

**ctBegin**()
 * Startar programmet/spelet. Se till att **ctSetup** och **ctBindFunctions** har tillkallats innan. Notera att genom att tillkalla denna funktionen låser du programmet i en loop.

**ctGetMousePosition**()
	* Retunerar en tuple (x, y) för musmarkörens position.

**ctGetWindowSize**()
	* Retunerar en tuple (bredd, höjd) för fönstrets storlek.

## Hantering av objekt.

Notera att om ni skapar ett objekt med **ctCreateObject** i t.ex. funktionen som är kopplad till **update** hanteringarna så kan ni inte använda er av t.ex. **ctMoveObject** innan nästa kallelse av **update**! Använd då istället **position** argumentet i **ctCreateObject** för att flytta objektet.

**ctCreateObject**( tag, image_path, (position), (size), (rotation), (name), (solid), (visible) )
 * Skapar ett nytt objekt med en bild.
 - **tag** en textsträng som anger taggen för det nya objektet.
 - **image_path** en textsträng till bilden som skall användas.
 - **position** en tuple (x, y) som anger positionen för objektet.
 - **size** en tuple (bredd, höjd) som anger storleken för objektet.
 - **rotation** ett nummer mellan 0 och 360 för objektets rotation moturs.
 - **name** en textsträng för ett namn, behöver inte vara unikt och har ingen betydelse utanför att namnge objekt.
 - **solid** en boolean som anger om andra objekt kan krocka med detta objektet.
 - **visible** en boolean som anger om detta objektet är synligt.

**ctCreateText**( tag, message, (color), (position), (size), (rotation), (name), (solid), (visible) )
 * Skapar ett nytt objekt med text.
 - **tag** en textsträng som anger taggen för det nya objektet.
 - **message** en textsträng för texten som skall visas.
 - **color** en RGBA tuple för textens färg.
 - **position** en tuple (x, y) som anger positionen för objektet.
 - **size** en tuple (bredd, höjd) som anger storleken för objektet.
 - **rotation** ett nummer mellan 0 och 360 för objektets rotation moturs.
 - **name** en textsträng för ett namn, behöver inte vara unikt och har ingen betydelse utanför att namnge objekt.
 - **solid** en boolean som anger om andra objekt kan krocka med detta objektet.
 - **visible** en boolean som anger om detta objektet är synligt.

**ctDestroyObject**( tag )
 * Används för att förstöra ett objekt, som redan måste finnas.
 - **tag** en textsträng för att identifiera det objekt som skall förstöras.

**ctSetObjectImage**( tag, image_path, (size) )
 * Ändrar bilden på ett objekt.
 - **tag** en textsträng för att identifiera objektet som skall ändras.
 - **image_path** en textsträng till bilden som skall användas.
 - **size** en tuple (bredd, höjd) som anger storleken för objektet. (om inget anges så kommer den nya bildens storlek att användas)

**ctSetObjectText**( tag, (message), (color), (size) )
 * Ändrar texten i ett objekt.
 - **tag** en textsträng för att identifiera objektet som skall ändras.
 - **message** en textsträng för texten som skall visas.
 - **color** en RGBA tuple för textens färg.
 - **size** en tuple (bredd, höjd) som anger storleken för objektet. (om inget anges så kommer den nya bildens storlek att användas)

## Flytta, Rotera och ändra på objekt.

Notera att programmet kan krasha eller bete sig konstigt om ni anger fel taggar eller fel typ av argument till funktionerna!

**ctPlaceObject**( tag, position )
 * Sättet objektet med den angivna taggen till **position** (x, y).

**ctPlaceCenterObject**( tag, position )
 * Sätter objektets center punkt med den angivna taggen till **position** (x, y).

**ctMoveObject**( tag, delta )
 * Flyttar objektet med den angivna taggen med **delta** (x, y) enheter.

**ctMoveObjectInDirection**( tag, delta )
 * Flyttar objektet med den angivna taggen med **delta** (x, y) enheter men räknar även in objektets rotation i förflyttningen.

**ctAngleObject**( tag, angle )
 * Sättet objektet med den angivna taggen till att ha rotationen som anges av **angle** i grader 0 till 360.

**ctRotateObject**( tag, angle )
 * Roterar objektet med den angivna taggen till med det som anges av **angle** i grader 0 till 360.

**ctSizeObject**( tag, size )
 * Sättet objektet med den angivna taggen till att ha storleken som anges av **size** (bredd, höjd) i pixlar.

**ctGetObjectPosition**( tag )
 * Retunerar objektet med den angivna taggens position (x, y).

**ctSetObjectPosition**( tag, position )
 * Sätter objektet med den angivna taggens position till **position** (x, y).

**ctGetObjectSize**( tag )
 * Retunerar objektet med den angivna taggens storlek (bredd, höjd).

**ctSetObjectSize**( tag, size )
 * Sätter objektet med den angivna taggens storlek till **size** (bredd, höjd).

**ctGetObjectRotation**( tag )
 * Retunerar objektet med den angivna taggens rotation i grader 0 till 360.

**ctSetObjectRotation**( tag, rotation )
 * Sätter objektet med den angivna taggens rotation till **rotation** i grader 0 till 360.

**ctGetObjectName**( tag )
 * Retunerar objektet med den angivna taggens namn.

**ctSetObjectName**( tag, name )
 * Sätter objektet med den angivna taggens namn till **name**.

**ctGetObjectHovered**( tag )
 * Retunerar en boolean om objektet med den angivna taggen har musmarkören över sig. Notera att detta värde endast har betydelse om ni har bundit **ray_cast**, **ray_cast_entered** eller **ray_cast_exited** via **ctBindFunctions**!

**ctGetObjectSolid**( tag )
 * Retunerar om objektet med den angivna taggen är hård och kan krocka med andra hårda objekt.

**ctSetObjectSolid**( tag, solid )
 * Sätter om objektet med den angivna taggen är hård och kan krocka med andra hårda objekt till **solid** som är en boolean.

**ctGetObjectVisible**( tag )
 * Retunerar om objektet med den angivna taggen är synligt.

**ctSetObjectVisible**( tag, visible )
 * Sätter om objektet med den angivna taggen är synligt till **visible** som är en boolean.

## Komihåg!

Detta är ett mycket enkelt tillägg till Pygame och kan innehålla fel eller buggar. Om ni tror att ni hittat något fel får ni gärna meddela oss!
