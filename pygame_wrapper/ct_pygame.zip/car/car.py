
from ct_pygame import *

#Window info.
WIN_WIDTH = 600
WIN_HEIGHT = 600

#Counters and other program variables.
LAPS_LEFT = 3
START_TIME = 600 * 2
TIME_LEFT = START_TIME
GAME_OVER = False
#To avoid cheating we will need to make sure the player
#passed the checkpoint line before reaching the finish line.
REACHED_CHECKPOINT = False

def buildLevel():
	global WIN_WIDTH, WIN_HEIGHT
	#Create some walls.
	ctCreateObject( "wall0", "wall.png", position = ( 0, 0 ), size = ( 64, WIN_HEIGHT ) )
	ctCreateObject( "wall1", "wall.png", position = ( 64, 0 ), size = ( WIN_WIDTH - 128, 64 ) )
	ctCreateObject( "wall2", "wall.png", position = ( WIN_WIDTH - 64, 0 ), size = ( 64, WIN_HEIGHT ) )
	ctCreateObject( "wall3", "wall.png", position = ( 64, WIN_HEIGHT - 64 ), size = ( WIN_WIDTH - 128, 64 ) )
	ctCreateObject( "wall4", "wall.png", position = ( 128, 128 ), size = ( WIN_WIDTH - 256, WIN_HEIGHT - 256 ) )
	#Create the finish line and checkpoint line.
	ctCreateObject( "finish", "finish.png", position = ( 110, 88 ), size = ( 64, 16 ), rotation = 90.0 )
	ctCreateObject( "checkpoint", "checkpoint.png", position = ( WIN_WIDTH - 167, WIN_HEIGHT - 104 ), size = ( 64, 16 ), rotation = 90.0 )

def updateTexts():
	global LAPS_LEFT, TIME_LEFT, REACHED_CHECKPOINT
	#Update displayed text for the timer and remaining laps.
	ctSetObjectText( "0timer", "Time left: " + str( TIME_LEFT / 10.0 ) )
	ctSetObjectText( "0laps", "Laps left: " + str( LAPS_LEFT ) )

def start():
	#Create the car.
	ctCreateObject( "car", "car.png", position = ( 100, 100 ), size = ( 32, 16 ) )
	#Create level.
	buildLevel()
	#Place timer and remaining laps counters. Note that the "0" in the tag is just for placing the text on top of the walls.
	ctCreateText( "0timer", "---" )
	ctCreateText( "0laps", "---", position = ( 200, 0 ) )
	#Print some instructions.
	ctCreateText( "instructions", "Move with arrow keys!", position = ( WIN_WIDTH / 2 - 132, WIN_HEIGHT / 2 - 100 ) )

def update():
	global WIN_WIDTH, WIN_HEIGHT, GAME_OVER, START_TIME
	global LAPS_LEFT, TIME_LEFT, REACHED_CHECKPOINT
	#Only update when not gameover.
	if not GAME_OVER:
		#Reduce remaining time.
		TIME_LEFT = TIME_LEFT - 1
		#Update counters.
		updateTexts()
		if LAPS_LEFT <= 0:
			#Finished the game.
			ctCreateText( "win", "YOUR TIME: " + str( ( START_TIME - TIME_LEFT ) / 10.0 ) + "!", position = ( WIN_WIDTH / 2 - 100, WIN_HEIGHT / 2 ) )
			GAME_OVER = True
		elif TIME_LEFT <= 0 and LAPS_LEFT > 0:
			#Out of time, game over.
			ctCreateText( "gameover", "GAME OVER!", position = ( WIN_WIDTH / 2 - 100, WIN_HEIGHT / 2 ) )
			GAME_OVER = True

def collision( name, tag0, tag1, corr ):
	global REACHED_CHECKPOINT, LAPS_LEFT
	is_car = False
	car_tag = tag0
	other_tag = tag1
	#Test if the 0 tag is the car.
	if "car" == tag0:
		is_car = True
	#Otherwise test if the 1 tag is the car.
	elif "car" == tag1:
		#Move around the values to avoid duplicated code.
		is_car = True
		car_tag = tag1
		other_tag = tag0
		corr = ( - corr[ 0 ], - corr[ 1 ] )
	#We only want to check for collisions on the car.
	if is_car:
		#Test if the car collided with the checkpoint line.
		if not REACHED_CHECKPOINT and other_tag == "checkpoint":
			REACHED_CHECKPOINT = True
		#Test if the car collided with the finish line.
		elif REACHED_CHECKPOINT and other_tag == "finish":
			REACHED_CHECKPOINT = False
			LAPS_LEFT = LAPS_LEFT - 1
		#If the other object is a wall then we want to correct the car
		#position to avoid collision.
		elif other_tag != "checkpoint" and other_tag != "finish":
			ctMoveObject( car_tag, corr )

def keyHeld( key ):
	global GAME_OVER
	#Only update the car when not gameover.
	if not GAME_OVER:
		#Up arrow key moves the car forward.
		if key == pygame.K_UP:
			ctMoveObjectInDirection( "car", ( 5, 0 ) )
		#Up arrow key moves the car forward.
		elif key == pygame.K_DOWN:
			ctMoveObjectInDirection( "car", ( -2, 0 ) )
		#Left arrow key turns the car to the left.
		elif key == pygame.K_LEFT:
			ctRotateObject( "car", +10.0 )
		#Right arrow key turns the car to the right.
		elif key == pygame.K_RIGHT:
			ctRotateObject( "car", -10.0 )

#Setup program and start.
ctSetup( WIN_WIDTH, WIN_HEIGHT, "Car game", background = ( 255, 255, 255, 255 ), fps = 30 )
ctBindFunctions( start, update, key_held = keyHeld, collision = collision )
ctBegin()
