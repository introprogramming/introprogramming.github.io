#A template file for CT_Pygame version 1.01

from ct_pygame import *

def start():
	ctCreateText( "my_text_object", "Hello world!", color = ( 0, 0, 0, 255 ), position = ( 720 / 2 - 72, 480 / 2 - 16 ) )

def update():
	ctRotateObject( "my_text_object", 4.0 )

def keyPressed( key ):
	pass

def keyReleased( key ):
	pass

def keyHeld( key ):
	pass

def mouseMoved( buttons ):
	mouse_position = ctGetMousePosition()
	pass

def mousePressed( button ):
	mouse_position = ctGetMousePosition()
	pass

def mouseReleased( button ):
	mouse_position = ctGetMousePosition()
	pass

def raycast( name, tag, abs_pos, rel_pos ):
	pass

def raycastEntered( name, tag, abs_pos, rel_pos ):
	pass

def raycastExited( name, tag, abs_pos, rel_pos ):
	pass

def collision( name, tag0, tag1, corr ):
	pass

#Setup program and start.
ctSetup( 720, 480, "My game", background = ( 255, 255, 255, 255 ), fps = 30 )
ctBindFunctions( start, update, keyPressed, keyReleased, keyHeld, mouseMoved, mousePressed, mouseReleased, raycast, raycastEntered, raycastExited, collision )
ctBegin()
