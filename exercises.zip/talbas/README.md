# Bin->dec & dec->bin converter

Konvertera mellan talbaserna binär och decimal

- **Svårighetsgrad:** 1

## Delmoment

1. Skapa en funktion som, givet ett binärt tal i strängform, ger dess decimala motsvarighet. *Svårighetsgrad 1*
2. Skapa en funktion som, givet ett decimalt tal i strängform, ger dess binära motsvarighet. *Svårighetsgrad 1*
3. Parsa commandline-arguments *Svårighetsgrad 1*

`$ python convert.py dec 5`  
`101`  
`$ python convert.py bin 101`  
`5`

## Utbyggnad

- Lägga till talbaserna oktalt och hexadecimalt

## Externa bibliotek

- (inga)