#!/bin/python
# A program which uses a for-loop to print "Hello, world!" 10 times

for i in range(10):
    print("Hello, world! %d" % i)




# in the print the % is a string format operator. essentially it replaces '%d' with the value of i
    
