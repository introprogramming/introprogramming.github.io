# Fibonacci-tal

En applikation som tar ett tal som input, och skriver ut det första [fibonacci-talet](http://en.wikipedia.org/wiki/Fibonacci_number) som är större än detta.

- **Svårighetsgrad:** 1

## Delmoment

1. Låt programmet ta emot input och skriv ut detta. **Svårighetsgrad:** 1
2. Skriv en metod som räknar ut och returnerar det första fibonacci-tal som är större än input-talet. Se till att ändra så att resultatet från metoden är det som skrivs ut istället. **Svårighetsgrad:** 1

## Utbyggnad

- Låt användaren kunna ange input-talet som ett argument till programmet, exempelvis:  
`python fibonacci.py 35`
- Prova att generera talserien [rekursivt](http://interactivepython.org/courselib/static/pythonds/Recursion/recursionsimple.html) istället för iterativt. **Svårighetsgrad:** 2